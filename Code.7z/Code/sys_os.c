#include "sys_os.h"

volatile unsigned char timers[MAXTASKS] = {0};
//volatile unsigned char timers_loop[MAX_LOOPTASKS]={0};
